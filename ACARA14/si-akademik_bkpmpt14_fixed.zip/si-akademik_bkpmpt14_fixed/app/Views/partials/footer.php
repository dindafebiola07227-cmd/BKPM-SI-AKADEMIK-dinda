<footer class="bg-light text-center py-3 mt-4">
    <p class="mb-0">&copy; 2026 SI Akademik</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>

